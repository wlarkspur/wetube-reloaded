# Wetube Reloaded

/ -> Home
/join -> Join
/login -> Login
/search -> Search


/users/:id -> See user
/users/logout -> Log Out
/users/edit -> Edit My Profile
/users/remove -> Remove My Profile

/videos/:id -> See Video
/videos/:id/edit -> Edit Video
/videos/:id/delete -> Delete Video
/videos/upload -> Upload Video

